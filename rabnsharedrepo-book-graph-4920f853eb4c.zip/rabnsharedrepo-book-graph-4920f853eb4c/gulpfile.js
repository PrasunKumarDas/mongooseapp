const semver           = require('semver');
const engines          = require('./package').engines;
const gulp             = require('gulp');
const gutil            = require('gulp-util');
const runSequence      = require('run-sequence');
const webpack          = require('webpack');
const webpackServer    = require('webpack-dev-server');
const opn              = require('opn');
const config           = {
  port: 4200,
  dev: gutil.env.dev,
  toolkit: {
    dest    : 'src/assets/toolkit',
    src     : [
      'toolkit/dist/assets/toolkit/**/*'
    ],
    watch   : [
      'toolkit/dist/assets/toolkit/**/*',
      '!{toolkit/dist/assets/toolkit/images/fpo,toolkit/dist/assets/toolkit/images/fpo/**}'
    ]
  }
};

let webpackConfig      = require('./webpack.config');

// Webpack
gulp.task('webpack', (done) => {
  let wp = webpack(webpackConfig, (err, stats) => {
    if (err) {
      gutil.log(gutil.colors.red(err()));
    }
    const result = stats.toJson();
    if (result.errors.length) {
      result.errors.forEach((error) => {
        gutil.log(gutil.colors.red(error));
      });
    }

    done();
  });
});

gulp.task('serve', (done) => {
  // Entries required for hot module replacement (HMR)
  webpackConfig.entry.main.unshift(
    "webpack/hot/dev-server",
    "webpack-dev-server/client?http://localhost:" + config.port
  );
  // Webpack plugins required for hot module replacement (HMR)
  // NamedModulesPlugin gives nice names for replacement modules in browser,
  // otherwise modules are just chunk numbers.
  webpackConfig.plugins.push(new webpack.HotModuleReplacementPlugin());
  webpackConfig.plugins.push(new webpack.NamedModulesPlugin());

  new webpackServer(webpack(webpackConfig), {
    hot: true, // enable hot module replacement (HMR) on webpack server
    stats: {
      colors: true // make compilation output pretty
    },
  })
  .listen(config.port, 'localhost', (err) => {
    if (err) {
      gutil.log(gutil.colors.red(err));
      done();
      return;
    }
    gutil.log(gutil.colors.green('[webpack-dev-server]'), 'Running on http://localhost:'+config.port);

    // open browser when server starts
    // --open for webpack-dev-server is CLI only
    opn('http://localhost:' + config.port + '/#/book/9780316407090');

    done();
  });

});

// toolkit build out to jam public folder
gulp.task('toolkit', (done) => {
  if (!config.hasOwnProperty('toolkit')) { done(); return }

  return gulp.src(config.toolkit.src)
  .pipe(gulp.dest(config.toolkit.dest));
});

gulp.task('toolkit:watch', (done) => {
  gulp.watch([config.toolkit.watch], ['toolkit']);
  done();
});

// default
gulp.task('default', (done) => {
  // const version = engines.node;
  // if ( ! semver.satisfies(process.version, version) ) {
  //   console.log(`Required node version ${version} not satisfied with current version ${process.version}.`);
  //   process.exit(1);
  // }

  if (config.dev) {
    runSequence(['toolkit'], ['toolkit:watch'], () => {
      gulp.start('serve');
      done();
    });
  } else {
    runSequence(['toolkit'], ['webpack'], () => {
      done();
    });
  }
});
