const path = require('path');
const ProgressPlugin = require('webpack/lib/ProgressPlugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const autoprefixer = require('autoprefixer');
const postcssUrl = require('postcss-url');

const {NoEmitOnErrorsPlugin, LoaderOptionsPlugin, DefinePlugin} = require('webpack');
const {GlobCopyWebpackPlugin, BaseHrefWebpackPlugin} = require('@angular/cli/plugins/webpack');
const {CommonsChunkPlugin} = require('webpack').optimize;
const {AotPlugin} = require('@ngtools/webpack');

const nodeModules = path.join(process.cwd(), 'node_modules');

const baseHref = "";
const deployUrl = "";

const ENV = process.env.NODE_ENV || 'development';
const API_URL = process.env.API_URL || 'http://localhost:3000/books2/';
const API_SUFFIX = process.env.API_SUFFIX || '';
const NEW_CONNECTION_URL = process.env.NEW_CONNECTION_URL || '/recommendations.html';

let webpackConfiguration = {
  "devtool": "source-map",
  "resolve": {
    "extensions": [
      ".ts", ".js"
    ],
    "modules": ["./node_modules"]
  },
  "resolveLoader": {
    "modules": ["./node_modules"]
  },
  "entry": {
    "book-graph": ["./src/polyfills.ts", "./src/app/styles/app.scss", "./src/main.ts"],
  },
  "output": {
    "path": path.join(process.cwd(), "./dist"),
    "filename": "[name].bundle.js",
    "chunkFilename": "[id].chunk.js"
  },
  "module": {
    "rules": [
      {
        "enforce": "pre",
        "test": /\.js$/,
        "loader": "source-map-loader",
        "exclude": [/\/node_modules\//]
      }, {
        "test": /\.json$/,
        "loader": "json-loader"
      }, {
        "test": /\.html$/,
        "loader": "raw-loader"
      }, {
        "test": /\.(eot|svg)$/,
        "loader": "file-loader?name=[name].[hash:20].[ext]"
      }, {
        "test": /\.(jpg|png|gif|otf|ttf|woff|woff2|cur|ani)$/,
        "loader": "url-loader?name=[name].[hash:20].[ext]&limit=10000"
      }, {
        "exclude": [path.join(process.cwd(), "src/app/styles/app.scss")],
        "test": /\.css$/,
        "loaders": ["exports-loader?module.exports.toString()", "css-loader?{\"sourceMap\":false,\"importLoaders\":1}", "postcss-loader"]
      }, {
        "exclude": [path.join(process.cwd(), "src/app/styles/app.scss")],
        "test": /\.scss$|\.sass$/,
        "loaders": ["exports-loader?module.exports.toString()", "css-loader?{\"sourceMap\":false,\"importLoaders\":1}", "postcss-loader", "sass-loader"]
      }, {
        "exclude": [path.join(process.cwd(), "src/app/styles/app.scss")],
        "test": /\.less$/,
        "loaders": ["exports-loader?module.exports.toString()", "css-loader?{\"sourceMap\":false,\"importLoaders\":1}", "postcss-loader", "less-loader"]
      }, {
        "exclude": [path.join(process.cwd(), "src/app/styles/app.scss")],
        "test": /\.styl$/,
        "loaders": ["exports-loader?module.exports.toString()", "css-loader?{\"sourceMap\":false,\"importLoaders\":1}", "postcss-loader", "stylus-loader?{\"sourceMap\":false,\"paths\":[]}"]
      }, {
        "include": [path.join(process.cwd(), "src/app/styles/app.scss")],
        "test": /\.css$/,
        "loaders": ExtractTextPlugin.extract({
          "use": [
            "css-loader?{\"sourceMap\":false,\"importLoaders\":1}", "postcss-loader"
          ],
          "fallback": "style-loader",
          "publicPath": ""
        })
      }, {
        "include": [path.join(process.cwd(), "src/app/styles/app.scss")],
        "test": /\.scss$|\.sass$/,
        "loaders": ExtractTextPlugin.extract({
          "use": [
            "css-loader?{\"sourceMap\":false,\"importLoaders\":1}", "postcss-loader", "sass-loader"
          ],
          "fallback": "style-loader",
          "publicPath": ""
        })
      }, {
        "include": [path.join(process.cwd(), "src/app/styles/app.scss")],
        "test": /\.less$/,
        "loaders": ExtractTextPlugin.extract({
          "use": [
            "css-loader?{\"sourceMap\":false,\"importLoaders\":1}", "postcss-loader", "less-loader"
          ],
          "fallback": "style-loader",
          "publicPath": ""
        })
      }, {
        "include": [path.join(process.cwd(), "src/app/styles/app.scss")],
        "test": /\.styl$/,
        "loaders": ExtractTextPlugin.extract({
          "use": [
            "css-loader?{\"sourceMap\":false,\"importLoaders\":1}", "postcss-loader", "stylus-loader?{\"sourceMap\":false,\"paths\":[]}"
          ],
          "fallback": "style-loader",
          "publicPath": ""
        })
      }, {
        "test": /\.ts$/,
        "loader": "@ngtools/webpack"
      }
    ]
  },
  "plugins": [
    new DefinePlugin({
      'API_URL': JSON.stringify(API_URL),
      'API_SUFFIX': JSON.stringify(API_SUFFIX),
      'NEW_CONNECTION_URL': JSON.stringify(NEW_CONNECTION_URL),
      'ENV': JSON.stringify(ENV),
    }),
    new NoEmitOnErrorsPlugin(),
    new GlobCopyWebpackPlugin({
      "patterns": [
        "assets", "favicon.ico"
      ],
      "globOptions": {
        "cwd": "src",
        "dot": true,
        "ignore": "**/.gitkeep"
      }
    }),
    new ProgressPlugin(),
    new BaseHrefWebpackPlugin({}),
    new CommonsChunkPlugin({
      "name": "book-graph",
      "minChunks": null,
      "chunks": "all",
    }),
    new ExtractTextPlugin({"filename": "[name].bundle.css", "disable": true}),
    new LoaderOptionsPlugin({
      "sourceMap": false,
      "options": {
        "postcss": [
          autoprefixer(),
          postcssUrl({
            "url": (URL) => {
              // Only convert root relative URLs, which CSS-Loader won't process into require().
              if (!URL.startsWith('/') || URL.startsWith('//')) {
                return URL;
              }
              if (deployUrl.match(/:\/\//)) {
                // If deployUrl contains a scheme, ignore baseHref use deployUrl as is.
                return `${deployUrl.replace(/\/$/, '')}${URL}`;
              } else {
                // Join together base-href, deploy-url and the original URL.
                // Also dedupe multiple slashes into single ones.
                return `/${baseHref}/${deployUrl}/${URL}`.replace(/\/\/+/g, '/');
              }
            }
          })
        ],
        "sassLoader": {
          "sourceMap": false,
          "includePaths": []
        },
        "lessLoader": {
          "sourceMap": false
        },
        "context": ""
      }
    }),
    new AotPlugin({
      "mainPath": "main.ts",
      "hostReplacementPaths": {
        "environments/environment.ts": "environments/environment.ts"
      },
      "exclude": [],
      "tsConfigPath": "src/tsconfig.app.json",
      "skipCodeGeneration": true
    })
  ],
  "node": {
    "fs": "empty",
    "global": true,
    "crypto": "empty",
    "tls": "empty",
    "net": "empty",
    "process": true,
    "module": false,
    "clearImmediate": false,
    "setImmediate": false
  }
};

const htmlPluginSettings = {
  "template": "./src/index.html",
  "filename": "./index.html",
  "hash": false,
  "inject": true,
  "compile": true,
  "favicon": false,
  "minify": false,
  "cache": true,
  "showErrors": true,
  "chunks": "all",
  "excludeChunks": [],
  "title": "Webpack App",
  "xhtml": true,
};

webpackConfiguration.plugins = webpackConfiguration.plugins
  .concat([
    {
      template: './src/index.html',
      filename: './index.html',
      inject: true
    },
    {
      template: './src/a11y.html',
      filename: './a11y.html',
      inject: true
    },
    {
      template: './src/pdp-books.html',
      filename: './pdp-books.html',
      inject: true
    },
    {
      template: './src/recommendations.html',
      filename: './recommendations.html',
      inject: false
    },
  ].map(file => {
    return new HtmlWebpackPlugin(Object.assign({}, htmlPluginSettings, file));
  }));

module.exports = webpackConfiguration;
