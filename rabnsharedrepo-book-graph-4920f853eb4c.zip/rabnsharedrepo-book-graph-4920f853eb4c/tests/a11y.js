var chai = require('chai');
var should = chai.should;
var expect = chai.expect;

var AxeBuilder = require('axe-webdriverjs'),
  WebDriver = require('selenium-webdriver');

var driver = new WebDriver.Builder()
  .forBrowser('phantomjs')
  .build();

describe('Stand alone book graph', function() {
  it('should have no critical accessibility problems', function(done) {
    this.timeout(30000);

    driver
      .get('http://localhost:4200/a11y.html')
      .then(function () {
        AxeBuilder(driver)
          .analyze(function (results) {
            try {
              expect(results.violations.length).to.equal(0);
              driver.quit();
              done();
            } catch(err) {
              err.expected = [];
              err.actual = results.violations.map(function(item){
                return {
                  description: item.description,
                  help: item.help,
                  helpUrl: item.helpUrl,
                  nodes: item.nodes.map(function(node){
                    var messages = [];
                    if ( node.any ) {
                      node.any.reduce(function(msg, aItem) {
                        messages.push(aItem.message);
                        return messages;
                      }, messages);
                    }
                    return {
                      messages: messages,
                      html: node.html,
                    };
                  }),
                };
              });

              driver.quit();
              done(err);
            }
          });
      });
  });
});
