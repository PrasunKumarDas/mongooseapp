declare let ENV;
declare let API_URL;
declare let API_SUFFIX;
declare let NEW_CONNECTION_URL;

export const environment = {
  production: ENV === 'production',
  productServiceEndpointPrefix: API_URL,
  productServiceEndpointSuffix: API_SUFFIX,
  newConnectionUrl: NEW_CONNECTION_URL,
};
