import {Injectable} from "@angular/core";

export enum LogLevel {
  None = 0,
  Error = 5,
  Warn = 8,
  Info = 10,
  Debug = 15,
  Verbose = 20
}

@Injectable()
export class LoggerService {
  /**
   * Sets application wide logger level to determain what level of logging should be supported for the environment.
   * @type {LogLevel}
   */
  static logLevel = LogLevel.Debug;

  /**
   * Logs any debugging through the logger and prints to console.
   */
  static debug(...args) {
    if (LoggerService.logLevel >= LogLevel.Debug) {
      console.log(`[DEBUG] [${this.constructor.name}]`, args.join(' '));
    }
  }

  /**
   * User for any non-critical errors within the application.
   */
  static error(...args) {
    if (LoggerService.logLevel >= LogLevel.Error) {
      console.error(`[ERROR] [${this.constructor.name}]`, args.join(' '));
    }
  }

  /**
   * User for any non-critical errors within the application.
   */
  static warn(...args) {
    if (LoggerService.logLevel >= LogLevel.Warn) {
      console.warn(`[WARNING] [${this.constructor.name}]`, args.join(' '));
    }
  }

  /**
   * High level logging beneficial in development and possibly production.
   */
  static info(...args) {
    if (LoggerService.logLevel >= LogLevel.Info) {
      console.log(`[INFO] [${this.constructor.name}]`, args.join(' '));
    }
  }
}
