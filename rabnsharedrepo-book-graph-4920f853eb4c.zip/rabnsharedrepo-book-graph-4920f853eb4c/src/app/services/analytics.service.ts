import { Injectable } from '@angular/core';
import { LoggerService } from "./logger.service";
import { getSelectedBook } from '../reducers/graphs';

declare let digitalData: any;
declare let _satellite: any;

@Injectable()
export class AnalyticsService {
  constructor() { }

  /**
   * Tracks an event with a specified category
   * @param category
   * @param event
   * @param label
   */
  trackCategoryEvent(event: any, eventType: string) {
    LoggerService.debug.call(this, `Tracking Event - ${eventType}, ${JSON.stringify(event)}`);
    if (digitalData) {
      digitalData.event.push(event);
      _satellite.track(eventType);
    } else {
      LoggerService.warn.call(this, 'digitalData is not defined');
    }
  }

  /**
   * Redux middleware factory for tracking events
   * @return redux middleware
   */
  getTrackingMiddleware() {
    return store => next => action => {
      const state = store.getState();

      switch (action.type) {
        case 'UPDATE_BOOK_STATE': {
          if (action.newState === 'selected') {
            const book = state.graphs.byId[action.graphId].byId[action.bookId];

            // first book
            if (state.graphs.byId[action.graphId].allIds.length === 1) {
              this.trackCategoryEvent({
                eventInfo: {
                  eventName: 'Book Graph Book Selected',
                  eventAction: 'onBookGraphBookSelected',
                  timeStamp: new Date(),
                },
                category: {
                  primaryCategory: 'Book Graph',
                },
                attributes: {
                  product: [{
                    category: {
                      primaryCategory: '',
                      productType: '',
                      subCategory: []
                    },
                    price: {
                      basePrice: 0
                    },
                    productInfo: {
                      productName: book.title,
                      productID: `prd${book.ean}`,
                      productURL: '',
                      sku: book.ean,
                      ratings: 0,
                      reviews: 0,
                      availability: '',
                    },
                    attributes: {
                      purchaseType: '',
                      notifyWhenStocked: false,
                      outOfStock: false,
                      isGiftCard: false,
                      isGiftWrap: false,
                      giftCardValue: 0,
                      isPhysicalProduct: false,
                      isDigitalProduct: false,
                      isNOOKProduct: false,
                      isDeviceProduct: false,
                      isEbookProduct: false,
                    }
                  }]
                }
              }, 'onBookGraphBookSelected');
            } else {
              this.trackCategoryEvent({
                eventInfo: {
                  eventName: 'Book Graph Additional Book Selected',
                  eventAction: 'onBookGraphAdditionalBookSelected',
                  timeStamp: new Date(),
                },
                category: {
                  primaryCategory: 'Book Graph',
                },
                attributes: {
                  product: [{
                    category: {
                      primaryCategory: '',
                      productType: '',
                      subCategory: []
                    },
                    price: {
                      basePrice: 0
                    },
                    productInfo: {
                      productName: book.title,
                      productID: `prd${book.ean}`,
                      productURL: '',
                      sku: book.ean,
                      ratings: 0,
                      reviews: 0,
                      availability: ''
                    },
                    attributes: {
                      purchaseType: '',
                      notifyWhenStocked: false,
                      outOfStock: false,
                      isGiftCard: false,
                      isGiftWrap: false,
                      giftCardValue: 0,
                      isPhysicalProduct: false,
                      isDigitalProduct: false,
                      isNOOKProduct: false,
                      isDeviceProduct: false,
                      isEbookProduct: false
                    }
                  }]
                }
              }, 'onBookGraphAdditionalBookSelected');
            }
          }
          break;
        }
        case 'ADD_GRAPH': {
          if (state.graphs.allIds.length === 1) {
            this.trackCategoryEvent({
              eventInfo: {
                eventName: 'Book Graph View',
                eventAction: 'onBookGraphView',
                timeStamp: new Date(),
              },
              category: {
                primaryCategory: 'Book Graph',
              },
              attributes: {
                errorCode: '',
                errorMessage: '',
              },
            }, 'onBookGraphView');
          }
          break;
        }
        case 'POP_GRAPH': {
          this.trackCategoryEvent({
            eventInfo: {
              eventName: 'Book Graph Go Back Click', // Fixed
              eventAction: 'onBookGraphGoBackClick', // Fixed
              timeStamp: new Date() // Fixed
            },
            category: {
              primaryCategory: 'Book Graph' // Fixed
            }
          }, 'onBookGraphGoBackClick');
          break;
        }
      }

      next(action);
    };
  }
}
