import { Injectable } from '@angular/core';
import { Http } from "@angular/http";
import 'rxjs/add/operator/toPromise';
import { NgRedux } from '@angular-redux/store';
import { IAppState } from '../store';
import {
  addGraph,
  setLock,
  updateBookDetails,
  updateBookState,
  addDetails,
  graphLoadError,
  graphInitLoadError,
  recallHistory,
  popGraph,
  clearGraphErrors
} from '../actions';
import { LayoutCorrelation } from './layout.correlation';
import { environment } from '../../environments/environment';
import { getAllGraphs } from '../reducers/graphs';
import { getAllBooks } from '../reducers/books';

declare const window;

@Injectable()
export class GraphService {

  private strategy = new LayoutCorrelation();
  private productServiceEndpointPrefix = environment.productServiceEndpointPrefix;
  private productServiceEndpointSuffix = environment.productServiceEndpointSuffix;
  private currentGraphs = [];

  constructor(private ngRedux:NgRedux<IAppState>, private http:Http) {
    ngRedux
      .select(state => state.graphs)
      .subscribe(graphs => {
        this.currentGraphs = graphs;
      });
  }

  getGraph(ean, selectedBook:any = {}) {
    this.http.get(`${this.productServiceEndpointPrefix}${ean}${this.productServiceEndpointSuffix}`)
        .toPromise()
        .then(result => this.strategy.execute(result))
        .then(data => {
          let books = data.books;
          let firstBook = books.slice(0,1);

          this.ngRedux.dispatch(clearGraphErrors());
          let remainingBooks = books.slice(1);
          if ( this.currentGraphs['allIds'] && this.currentGraphs['allIds'].length === 0 ) {
            this.ngRedux.dispatch(addGraph(firstBook));
            this.ngRedux.dispatch(addGraph(remainingBooks));
          } else {
            this.ngRedux.dispatch(addGraph(remainingBooks));
          }

          this.ngRedux.dispatch(addDetails(firstBook[0].ean, data.details));

          this.ngRedux.dispatch(setLock(false));
        })
        .catch(err => {
          let cause = 'Sorry, we\'re unable to load your Book Graph right now.';

          // Init failed
          if ( this.currentGraphs['allIds'] && this.currentGraphs['allIds'].length === 0 ) {
            this.ngRedux.dispatch(graphInitLoadError(cause, ean));

          // Failed graph load
          } else {
            window.setTimeout(() => {
              cause = 'Sorry, we were unable to redraw your graph.';
              this.ngRedux.dispatch(graphLoadError(cause, ean));
              this.ngRedux.dispatch(addGraph([]));
              this.ngRedux.dispatch(recallHistory());
              this.ngRedux.dispatch(popGraph());
              this.ngRedux.dispatch(setLock(false));
            }, 500);
          }

          console.error(err);
        });
  }
}
