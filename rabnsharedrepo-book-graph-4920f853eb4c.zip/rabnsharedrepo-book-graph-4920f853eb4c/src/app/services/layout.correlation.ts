import { v4 } from 'uuid';

export class LayoutCorrelation {
  execute(data) {
    return new Promise<{books: any[], details}>(resolve => resolve({
      books: this.parseNodes(data.json()),
      details: data.json().details
    }));
  }

  protected parseNodes(tree, column = 2, row = 3, depth = 0, books = []) {
    switch ( depth ) {
      case 0: {
        let [ book ] = tree.nodes;

        books.push({
          id: v4(),
          ean: book.ean,
          title: book.title,
          contributor: book.primaryContributor,
          pdpUrl: book.pdp,
          contributorUrl: book.authorpage,
          imageUrl: book.sizeimage.replace(/\{size\}/, '600x595'),
          column,
          row,
          state: 'loading',
        });
        books = this.parseNodes(book.relationships[0], column + 1, row - 2, depth + 1, books);
        books = this.parseNodes(book.relationships[1], column + 1, row + 2, depth + 1, books);

        return books.sort((a,b)=>{
          // COL/ROW
          let index = 0;
          const order = {
            '2,3': index,
            '3,1': index++,
            '4,0': index++,
            '5,0': index++,
            '6,0': index++,
            '7,0': index++,
            '4,2': index++,
            '5,2': index++,
            '6,2': index++,
            '7,2': index++,
            '3,5': index++,
            '4,4': index++,
            '5,4': index++,
            '6,4': index++,
            '7,4': index++,
            '4,6': index++,
            '5,6': index++,
            '6,6': index++,
            '7,6': index++,
          }
          let aIndex = `${a.column},${a.row}`;
          let bIndex = `${b.column},${b.row}`;

          if (order[aIndex] < order[bIndex] ) return -1;
          if (order[aIndex] > order[bIndex] ) return 1;
          return 0;
        });
      }
      case 1: {
        let book  = tree.node;

        books.push({
          id: v4(),
          ean: book.ean,
          title: book.title,
          contributor: book.primaryContributor,
          pdpUrl: book.pdp,
          contributorUrl: book.authorpage,
          imageUrl: book.sizeimage.replace(/\{size\}/, '600x595'),
          column,
          row,
          state: 'loading',
        });
        books = this.parseNodes(book.relationships[0], column + 1, row - 1, depth + 1, books);
        books = this.parseNodes(book.relationships[1], column + 1, row + 1, depth + 1, books);

        return books;

      }
      default: {
        if ( ! tree ) {
          return books;
        }

        let book  = tree.node;

        books.push({
          id: v4(),
          ean: book.ean,
          title: book.title,
          contributor: book.primaryContributor,
          pdpUrl: book.pdp,
          contributorUrl: book.authorpage,
          imageUrl: book.sizeimage.replace(/\{size\}/, '600x595'),
          column,
          row,
          state: 'loading',
        });

        if ( book.relationships ) {
          books = this.parseNodes(book.relationships[0], column + 1, row, depth + 1, books);
        }

        return books;
      }
    }
  }

}
