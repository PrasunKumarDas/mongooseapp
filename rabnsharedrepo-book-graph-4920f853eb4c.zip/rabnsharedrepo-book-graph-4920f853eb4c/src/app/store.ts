import { combineReducers, Reducer } from 'redux';
import { graphs } from './reducers/graphs';
import { app } from './reducers/app';
import { details } from './reducers/details';
import { addGraph } from './actions';

export interface IAppState {
  graphs,
  app,
  details
}

export const rootReducer = combineReducers({
  graphs,
  app,
  details
});

export const INITIAL_STATE: IAppState = {
  graphs: {},
  app: {
    pdp: false,
    pdpOpened: false,
    locked: false,
    detailsOpened:false,
    error: false,
  },
  details: {}
};
