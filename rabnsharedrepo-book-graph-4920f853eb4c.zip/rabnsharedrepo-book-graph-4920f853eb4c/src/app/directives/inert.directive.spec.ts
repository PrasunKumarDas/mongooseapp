import { InertDirective } from './inert.directive';

describe('InertDirective', () => {
  it('should create an instance', () => {
    const directive = new InertDirective();
    expect(directive).toBeTruthy();
  });
});
