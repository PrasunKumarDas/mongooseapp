import { Directive, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[bgInert]'
})
export class InertDirective {

  @Input() bgInert: boolean;

  constructor(private el: ElementRef) {}

  ngOnInit() {
    if ( this.bgInert ) {
      this.el.nativeElement.setAttribute('inert', '');
    } else {
      this.el.nativeElement.removeAttribute('inert');
    }
  }

  ngOnChanges() {
    if ( this.bgInert ) {
      this.el.nativeElement.setAttribute('inert', '');
    } else {
      this.el.nativeElement.removeAttribute('inert');
    }
  }

}
