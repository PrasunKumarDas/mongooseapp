import { combineReducers } from 'redux';
import { book } from './book';

export const getAllBooks = (state) => state.allIds.map(id => state.byId[id]);

export const selectedBooks = (state) => getAllBooks(state).filter(book => book.state === 'selected');

const byId = (state = {}, action) => {
  switch (action.type) {
    case 'ADD_GRAPH':
      return action.books.reduce((state, book) => ({
        ...state,
        [book.id]: {
          graphId: action.id,
          ...book
        }
      }), {});
      case 'UPDATE_HISTORY': {
        let newState = {};
        for ( let id of Object.keys(state) ) {
          newState[id] = {
            ...state[id]
          };

          if ( state[id].state === 'selected' ){
            newState[id].state = 'history1';
          } else if( state[id].state === 'history1' ){
            newState[id].state = 'history2';
          }
        }
        return newState;
      }
      case 'RECALL_HISTORY': {
        let newState = {};
        for ( let id of Object.keys(state) ) {
          newState[id] = {
            ...state[id]
          };
          if ( action.depth === 1 && state[id].state === 'hidden' ){
            newState[id].state = 'loaded';
          }
          if ( action.depth === 1 && state[id].state === 'selected' ){
            newState[id].state = 'loaded';
          } else if( action.depth === 2 && state[id].state === 'history1' ){
            newState[id].state = 'selected';
          } else if( action.depth === 3 && state[id].state === 'history2' ){
            newState[id].state = 'history1';
          } else if( state[id].state === 'loaded' ){
            newState[id].state = 'exit';
          }
        }
        return newState;
      }
      case 'UPDATE_BOOK_STATE':
      case 'UPDATE_BOOK_DETAILS':
      return {
        ...state,
        [action.bookId]: book(state[action.bookId], action),
      };
  }

  return state;
}

const allIds = (state = [], action) => {
  switch (action.type) {
    case 'ADD_GRAPH':
      return action.books.map(book => book.id);
  }

  return state;
}

export const books = combineReducers({
  byId,
  allIds
});
