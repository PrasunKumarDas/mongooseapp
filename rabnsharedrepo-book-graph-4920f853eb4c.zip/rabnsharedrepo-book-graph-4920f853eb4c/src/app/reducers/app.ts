export const app = (state = { locked: false }, action) => {
  switch (action.type) {
    case 'CLEAR_GRAPH_ERROR': {
      return {
        ...state,
        error: false,
      };
    }
    case 'GRAPH_INIT_ERROR':
    case 'GRAPH_LOAD_ERROR': {
      return {
        ...state,
        error: {
          init: action.init,
          cause: action.cause,
          ean: action.ean,
        },
      };
    }
    case 'SET_LOCK': {
      return {
        ...state,
        locked: action.locked,
      };
    }
    case 'SET_PDP': {
      return {
        ...state,
        pdp: action.pdp,
      };
    }
    case 'SET_PDP_OPENED': {
      return {
        ...state,
        pdpOpened: action.opened,
      };
    }
    case 'SET_DETAILS_OPENED': {
      return {
        ...state,
        detailsOpened: action.detailsOpened,
      };
    }
  }

  return state;
};
