import { combineReducers } from 'redux';
import { books } from './books';
import { selectedBooks } from './books';

export const getAllGraphs = (state) => state.allIds.map(id => ({
  id,
  books: state.byId[id]
}));

export const getSelectedBook = (state) => {
  if ( state.selected ) {
    if ( state.byId[state.selected.graphId] ) {
      return state.byId[state.selected.graphId].byId[state.selected.bookId];
    }
  }

  return null;
};

const byId = (state = {}, action) => {
  switch (action.type) {
    case 'ADD_GRAPH':
      return {
        ...state,
        [action.id]: books(state[action.id], action)
      };

    case 'UPDATE_HISTORY':
    case 'UPDATE_BOOK_STATE':
    case 'UPDATE_BOOK_DETAILS':
      return {
        ...state,
        [action.graphId]: books(state[action.graphId], action)
      };
    case 'POP_GRAPH':
      let newState = {};

      const graphIds = Object.keys(state);
      newState = { ...state };
      delete newState[graphIds[graphIds.length - 1]];

      return newState;

    case 'RECALL_HISTORY': {
      let newState = {};
      const graphIds = Object.keys(state);

      for ( let index = 0; index < graphIds.length; index++ ) {
        let depth = graphIds.length - index - 1;
        let graphId = graphIds[index];
        // No change for deeper graphs
        if ( depth > 5 ) {
          newState[graphId] = state[graphId];
        } else {
          newState[graphId] = books(state[graphId], { ...action, depth });
        }
      }

      return newState;
    }

  }

  return state;
}

const allIds = (state = [], action) => {
  switch (action.type) {
    case 'ADD_GRAPH':
      return [
        ...state,
        action.id
      ];
    case 'POP_GRAPH': {
      let newState = [...state];
      newState.pop();
      return newState;
    }

  }

  return state;
}

const selected = (state = null, action) => {
  if ( action.type === 'UPDATE_BOOK_STATE' && action.newState === 'selected' ) {
    return {
      graphId: action.graphId,
      bookId: action.bookId,
    };
  }

  return state;
};

export const graphs = combineReducers({
  byId,
  allIds,
  selected,
});
