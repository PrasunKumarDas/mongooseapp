import { combineReducers } from 'redux';

export const getAllDetails = (state) => state.allIds.map(id => state.byId[id]);

const byId = (state = {}, action) => {
  switch (action.type) {
    case 'ADD_DETAILS':
      return {
        ...state,
        [action.id]: action.details
      };
  }

  return state;
}

const allIds = (state = [], action) => {
  switch (action.type) {
    case 'ADD_DETAILS':
      return [
        ...state,
        action.id
      ];
  }

  return state;
}

export const details = combineReducers({
  byId,
  allIds
});
