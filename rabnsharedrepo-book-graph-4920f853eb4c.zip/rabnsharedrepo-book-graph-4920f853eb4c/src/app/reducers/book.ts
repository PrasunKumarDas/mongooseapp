export const book = (state = {}, action) => {
  switch (action.type) {
    case 'UPDATE_BOOK_STATE': {
      return {
        ...state,
        state: action.newState
      };
    }
    case 'UPDATE_BOOK_DETAILS': {
      return {
        ...state,
        rating: action.rating,
        reviews: action.reviews,
        description: action.description,
      };
    }
  }

  return state;
};
