// Modules
import { RouterModule, Routes } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Store, createStore, applyMiddleware } from 'redux';
import { NgReduxModule, NgRedux } from '@angular-redux/store';

// Redux State Management
import { rootReducer, IAppState, INITIAL_STATE } from './store';

// Services
import { GraphService } from './services/graph.service';
import { LoggerService, LogLevel } from './services/logger.service';
import { AnalyticsService } from './services/analytics.service';

import { environment } from '../environments/environment';
declare let window, document;

// Components
import { AppComponent } from './components/app/app.component';
import { GraphComponent } from './components/graph/graph.component';
import { BookComponent } from './components/book/book.component';
import { LinesComponent } from './components/lines/lines.component';
import { ReverseOrderPipe } from './pipes/reverse-order.pipe';
import { DetailsComponent } from './components/details/details.component';
import { BootstrapComponent } from './components/bootstrap/bootstrap.component';
import { LimitCharsPipe } from './pipes/limit-chars.pipe';
import { InertDirective } from './directives/inert.directive';
import { LoadErrorComponent } from './components/load-error/load-error.component';
import { TruncateAtPipe } from './pipes/truncate-at.pipe';

const appRoutes: Routes = [
  { path: 'book/:ean', component: AppComponent },
  { path: '**', component: AppComponent },
];

// Providers
@NgModule({
  declarations: [
    AppComponent,
    GraphComponent,
    BookComponent,
    LinesComponent,
    ReverseOrderPipe,
    DetailsComponent,
    BootstrapComponent,
    LimitCharsPipe,
    InertDirective,
    LoadErrorComponent,
    TruncateAtPipe,
  ],
  imports: [
    RouterModule.forRoot(appRoutes, { useHash: true }),
    BrowserModule,
    FormsModule,
    HttpModule,
    NgReduxModule,
  ],
  providers: [
    GraphService,
    LoggerService,
    AnalyticsService,
  ],
  bootstrap: [BootstrapComponent]
})
export class AppModule {
  constructor(
    ngRedux: NgRedux<IAppState>, analyticsService: AnalyticsService) {
    const store = createStore(rootReducer, INITIAL_STATE, applyMiddleware(analyticsService.getTrackingMiddleware())) as Store<IAppState>;

    ngRedux.provideStore(store);

    // Logging and AnalyticsService
    LoggerService.logLevel = environment.production ? LogLevel.None : LogLevel.Debug;
    AppModule.setupAnalytics();
  }

  private static setupAnalytics() {
    window['digitalData'] = window['digitalData'] || {};
    window['digitalData']['event'] = window['digitalData']['event'] || [];
    window['_satellite'] = window['_satellite'] || {
      track: event => {
        LoggerService.debug.call(this, `_satellite(${event}) called`);
      },
    };
  }
}
