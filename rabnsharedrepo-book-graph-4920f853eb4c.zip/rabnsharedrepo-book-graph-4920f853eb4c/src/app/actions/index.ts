import { v4 } from 'uuid';

export const clearGraphErrors = () => ({
  type: 'CLEAR_GRAPH_ERROR'
});

export const graphInitLoadError = (cause, ean) => ({
  type: 'GRAPH_INIT_ERROR',
  init: true,
  cause,
  ean,
});

export const graphLoadError = (cause, ean) => ({
  type: 'GRAPH_LOAD_ERROR',
  init: false,
  cause,
  ean,
});

export const setPdp = pdp => ({
  type: 'SET_PDP',
  pdp
});

export const setPdpOpened = opened => ({
  type: 'SET_PDP_OPENED',
  opened
});

export const setLock = locked => ({
  type: 'SET_LOCK',
  locked
});

export const setDetailsOpened = detailsOpened => ({
  type: 'SET_DETAILS_OPENED',
  detailsOpened
});

export const addGraph = (books = []) => ({
  type: 'ADD_GRAPH',
  id: v4(),
  books
});

export const popGraph = () => ({
  type: 'POP_GRAPH',
});

export const updateHistory = (graphId ) => {
  return {
    type: 'UPDATE_HISTORY',
    graphId
  }
};

export const recallHistory = () => {
  return {
    type: 'RECALL_HISTORY'
  }
};

export const updateBookDetails = (graphId, bookId, { rating, reviews, description } = {
  rating: 0,
  reviews: 0,
  description: ''
}) => {
  return {
    type: 'UPDATE_BOOK_DETAILS',
    graphId,
    bookId,
    rating,
    reviews,
    description,
  };
}

export const updateBookState = (graphId, bookId, newState = '') => {
  return {
    type: 'UPDATE_BOOK_STATE',
    graphId,
    bookId,
    newState,
  }
};

export const addDetails = (bookEan, details = {}) => {
  return {
    type: 'ADD_DETAILS',
    id: bookEan,
    details: {
      ...details,
      ean: bookEan,
    },
  };
};
