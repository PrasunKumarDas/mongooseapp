import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'bg-banner',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.scss']
})
export class BannerComponent implements OnInit {

  @Input() app;

  constructor() {
    console.log(this.app);
  }

  ngOnInit() {
  }

}
