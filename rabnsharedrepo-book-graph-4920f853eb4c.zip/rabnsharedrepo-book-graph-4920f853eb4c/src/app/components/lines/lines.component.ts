import { Component, OnInit, ElementRef, Input } from '@angular/core';
import { TweenMax, TimelineMax, Power3, Power2, Linear} from "gsap";

import { IAppState } from '../../store';
import { NgRedux } from '@angular-redux/store';

import { getAllGraphs } from '../../reducers/graphs';
import { getAllBooks } from '../../reducers/books';

import {recallHistory, setLock, popGraph } from '../../actions';

const COLUMNS = [-449, -71, 307, 583, 783, 942, 1083, 1223];
const ROWS = [93, 167, 241, 325, 409, 483, 557];

@Component({
  selector: 'bg-lines',
  templateUrl: './lines.component.html',
  styleUrls: ['./lines.component.scss']
})
export class LinesComponent {
  private graphTimeline;
  private nodeTimeline;
  private arrow;
  private leftLine;
  private rightLine;
  private arrowLength;
  private tipShown = false;
  private locked = false;
  private previousGraphLength = 0;
  private nodes = [{ column: 3, row: 1 }, { column: 4, row: 0 }, { column: 5, row: 0 }, { column: 6, row: 0 }, { column: 7, row: 0 }, { column: 4, row: 2 }, { column: 5, row: 2 }, { column: 6, row: 2 }, { column: 7, row: 2 }, { column: 3, row: 5 }, { column: 4, row: 4 }, { column: 5, row: 4 }, { column: 6, row: 4 }, { column: 7, row: 4 }, { column: 4, row: 6 }, { column: 5, row: 6 }, { column: 6, row: 6 }, { column: 7, row: 6 }];
  private pairs = new Map();
  private books = [];

  constructor(private el: ElementRef, private ngRedux: NgRedux<IAppState>) {
    this.pairs.set("c3r1", { column: 2, row: 3 });
    this.pairs.set("c4r0", { column: 3, row: 1 });
    this.pairs.set("c5r0", { column: 4, row: 0 });
    this.pairs.set("c6r0", { column: 5, row: 0 });
    this.pairs.set("c7r0", { column: 6, row: 0 });
    this.pairs.set("c4r2", { column: 3, row: 1 });
    this.pairs.set("c5r2", { column: 4, row: 2 });
    this.pairs.set("c6r2", { column: 5, row: 2 });
    this.pairs.set("c7r2", { column: 6, row: 2 });
    this.pairs.set("c3r5", { column: 2, row: 3 });
    this.pairs.set("c4r4", { column: 3, row: 5 });
    this.pairs.set("c5r4", { column: 4, row: 4 });
    this.pairs.set("c6r4", { column: 5, row: 4 });
    this.pairs.set("c7r4", { column: 6, row: 4 });
    this.pairs.set("c4r6", { column: 3, row: 5 });
    this.pairs.set("c5r6", { column: 4, row: 6 });
    this.pairs.set("c6r6", { column: 5, row: 6 });
    this.pairs.set("c7r6", { column: 6, row: 6 });
  }

  ngAfterViewInit() {
    this.initGraph();
    this.showGraph();

    this.ngRedux
      .select(state => state)
      .subscribe(state => {
        if ( this.locked !== state.app.locked ) {
          this.locked = state.app.locked;
          if ( this.locked ) {
            this.hideGraph();
          } else {
            this.showGraph();
          }
        }

        let currentGraphLength = state.graphs.allIds.length;
        if ( currentGraphLength ) {
          this.books = getAllBooks(state.graphs.byId[state.graphs.allIds[currentGraphLength - 1]]);
        }

        if ( currentGraphLength != this.previousGraphLength ) {
          if ( currentGraphLength >= 3 ) {
            this.showHistory();
          }

          if ( currentGraphLength < 3 ) {
            this.hideHistory();
          }

          if ( ! this.tipShown ) {
            if ( currentGraphLength == 3 && ! state.app.error ) {
              TweenMax.delayedCall(1, this.showTip.bind(this));
              this.tipShown = true;
            }
          }

          if ( this.previousGraphLength > currentGraphLength ) {
            this.hideTip();
          }
        }

        this.previousGraphLength = currentGraphLength;
      });
  }

  activeNodes() {
    return this.nodes.map(node => {
      for ( let book of this.books ) {
        if ( node.column === book.column && node.row === book.row ) {
          return {
            ...node,
            visible: true,
          };
        }
      }

      return {
        ...node,
        visible: false,
      };
    });
  }

  initGraph() {
    TweenMax.from("line", 0.5, { autoAlpha: 0 });
    this.graphTimeline = new TimelineMax({
      paused: true
    });
    this.nodeTimeline = new TimelineMax({
      paused: true
    });
    this.arrow = this.el.nativeElement.querySelector(".arrow");
    this.leftLine = this.el.nativeElement.querySelector(".left-line");
    this.rightLine = this.el.nativeElement.querySelector(".right-line");
    this.arrowLength = this.arrow.getTotalLength();

    let duration = 1;
    for (let c = 3; c <= 7; c++) {
      let lineColumn = this.el.nativeElement.querySelectorAll("line.c" + c);

      for (let l = 0; l < lineColumn.length; l++) {
        let line = lineColumn[l];
        this.initLine(line);
        this.graphTimeline.from(line, duration, {
          attr: {
            x2: line.initX1,
            y2: line.initY1
          },
          ease: Linear.easeNone
        }, (c - 3) * duration);

        this.graphTimeline.to(line, duration, {
          attr: {
            x1: line.initX2,
            y1: line.initY2
          },
          strokeDashoffset: line.length,
          ease: Linear.easeNone
        }, (c + 2) * duration);
      }
    }
    this.nodeTimeline.staggerFrom(["circle.c2", "circle.c3", "circle.c4", "circle.c5", "circle.c6", "circle.c7"], duration * .25, {
      scale: 0,
      transformOrigin: "center",
      ease: Linear.easeNone
    }, duration, 0);

    this.nodeTimeline.staggerTo(["circle.c2", "circle.c3", "circle.c4", "circle.c5", "circle.c6", "circle.c7"], duration * .25, {
      scale: 0,
      transformOrigin: "center",
      ease: Linear.easeNone
    }, duration, this.nodeTimeline.duration());
    this.initLine(this.leftLine);
    this.initLine(this.rightLine);

    TweenMax.set(this.leftLine, {
      attr: {
        x2: this.leftLine.initX1
      },
      autoAlpha: 0,
    });

    TweenMax.set(this.rightLine, {
      attr: {
        x2: this.rightLine.initX1
      },
      autoAlpha: 0,
    });

    TweenMax.set(".historical-button", {
      autoAlpha: 0,
      scale: 0.5,
      transformOrigin: "center"
    });
    TweenMax.set(this.arrow, {
      strokeDasharray: this.arrowLength,
      strokeDashoffset: this.arrowLength
    });
    TweenMax.set(this.el.nativeElement.querySelector("svg"), {
      opacity: 1
    });
  }

  initLine(line) {
    line.initX1 = Number(line.getAttribute("x1"));
    line.initY1 = Number(line.getAttribute("y1"));
    line.initX2 = Number(line.getAttribute("x2"));
    line.initY2 = Number(line.getAttribute("y2"));
    var dx = line.initX1 - line.initX2;
    var dy = line.initY1 - line.initY2;
    line.length = Math.sqrt(dx * dx + dy * dy);
  }

  hasHistory() {
    return this.previousGraphLength >= 3;
  }

  showHistory() {
    TweenMax.killTweensOf(".historical-button");
    TweenMax.killTweensOf(this.leftLine, { attr: true });
    TweenMax.killTweensOf(this.rightLine, { attr: true });
    TweenMax.to(".historical-button", 0.5, {
      autoAlpha: 1,
      scale: 1,
      transformOrigin: "center",
      ease: Power2.easeOut
    });
    TweenMax.to(this.leftLine, 0.5, {
      attr: {
        x2: this.leftLine.initX2
      },
      ease: Power2.easeInOut,
      autoAlpha: 1,
    });
    TweenMax.to(this.rightLine, 0.5, {
      attr: {
        x2: this.rightLine.initX2
      },
      ease: Power2.easeInOut,
      autoAlpha: 1,
    });
  }

  hideHistory() {
    TweenMax.killTweensOf(".historical-button");
    TweenMax.killTweensOf(this.leftLine, { attr: true });
    TweenMax.killTweensOf(this.rightLine, { attr: true });
    TweenMax.to(".historical-button", 0.5, {
      autoAlpha: 0,
      scale: 0.5,
      transformOrigin: "center",
      ease: Power2.easeOut
    });
    TweenMax.to(this.leftLine, 0.3, {
      attr: {
        x2: this.leftLine.initX1
      },
      autoAlpha: 0,
      ease: Power2.easeInOut
    });
    TweenMax.to(this.rightLine, 0.3, {
      attr: {
        x2: this.rightLine.initX1
      },
      autoAlpha: 0,
      ease: Power2.easeInOut
    });
  }

  showTip() {
    TweenMax.to(this.arrow, 0.5, {
      strokeDashoffset: 0,
      ease: Power2.easeOut
    });
    TweenMax.to(".tip text", 0.5, {
      autoAlpha: 1,
      ease: Power2.easeOut
    });
  }

  hideTip() {
    TweenMax.to(this.arrow, 0.5, {
      strokeDashoffset: this.arrowLength,
      ease: Power2.easeOut
    });
    TweenMax.to(".tip text", 0.5, {
      autoAlpha: 0,
      ease: Power2.easeOut
    });
  }

  showGraph() {
    TweenMax.staggerTo([this.nodeTimeline, this.graphTimeline], 0.5, {
      progress: 0.5,
      ease: Power2.easeInOut
    });
  }

  hideGraph() {
    TweenMax.staggerTo([this.nodeTimeline, this.graphTimeline], 0.5, {
      progress: 0,
      ease: Power2.easeInOut,
    });
  }

  getColumn(column) {
    return COLUMNS[column];
  }

  getRow(row) {
    return ROWS[row];
  }

  getPreviousNode(column, row) {
    return this.pairs.get("c" + column + "r" + row);
  }


  onHistorical(e) {
    e.preventDefault();

    // prevent multiple clicks before animation completes
    if ( this.locked ) return;

    this.ngRedux.dispatch(setLock(true));
    this.ngRedux.dispatch(recallHistory());
    TweenMax.delayedCall(0.8, () => {
      this.ngRedux.dispatch(popGraph());
      this.ngRedux.dispatch(setLock(false));
    });
  }

  trackPosition(index, book) {
    return "c" + book.column + "r" + book.row;
  }
}
