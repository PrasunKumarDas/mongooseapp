import { ActivatedRoute } from '@angular/router';
import { Component, OnInit, ElementRef } from '@angular/core';
import { IAppState } from '../../store';
import { NgRedux } from '@angular-redux/store';
import { getAllGraphs } from '../../reducers/graphs';
import { setPdp, setPdpOpened } from '../../actions';
import { environment } from '../../../environments/environment';
import { AnalyticsService } from '../../services/analytics.service';

// Services
import { GraphService } from '../../services/graph.service';

const colors = ["#15847a", "#085e58", "#28483d", "#3f5c5f", "#004d70", "#107794", "#107794", "#0e2c4e", "#3a527e", "#4f3a7e", "#7e3a6c", "#b82e5e", "#3b3c72", "#294d75", "#125891"];

declare let window;

@Component({
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  private version = '1.3.0';
  private graphs = [];
  private locked;
  private detailsOpened;
  private loadEan: Number;
  private readonly ratio = 650 / 1450;
  private pdpMode = false;
  private pdpOpened = false;
  private tipVisible = false;
  private initializing = true;
  private tipDismissed = false;
  private error: any = false;
  private newConnectionUrl = environment.newConnectionUrl || '/recommendations.html';;

  constructor(
    private el: ElementRef,
    private ngRedux: NgRedux<IAppState>,
    private graphService: GraphService,
    private activatedRoute: ActivatedRoute,
    private analyticsService: AnalyticsService
  ) {
    // Leave this in for QA
    console.log(`====== B&N Book Graph version: ${this.version} ======`);

    ngRedux
      .select(state => state.graphs)
      .subscribe(state => {
        this.graphs = getAllGraphs(state);

        this.el.nativeElement.style.background = colors[this.graphs.length % colors.length];
      });

    ngRedux
      .select(state => state.app)
      .subscribe(app => {
        this.locked = app.locked;
        this.pdpMode = app.pdp;
        this.pdpOpened = app.pdpOpened;
        if (this.graphs.length > 0) {
          this.initializing = false;
          this.onResize();
        }

        this.error = app.error;
      });

    ngRedux
      .select(state => state.app)
      .subscribe(app => {
        this.detailsOpened = app.detailsOpened;
      });

    window.addEventListener("resize", this.onResize.bind(this));
    window.addEventListener("scroll", this.onScroll.bind(this));
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.loadEan = params['ean'];
    });

    // Pdp mode
    if (!this.loadEan && window.digitalData) {
      this.loadEan = window.digitalData.product[0].productInfo.sku;
      this.ngRedux.dispatch(setPdp(true));
    }

    if (this.loadEan) {
      this.graphService.getGraph(this.loadEan);
    }

    this.onResize();
  }

  togglePdpOpened() {
    this.ngRedux.dispatch(setPdpOpened(!this.pdpOpened));
    this.dismissTip();
  }

  isCurrent(graph) {
    let length = this.graphs.length;
    return length === 1 || graph.id === this.graphs[length - 1].id;
  }

  trackGraph(index, graph) {
    return graph.id;
  }

  onResize() {
    if (this.initializing) return;

    let container = this.el.nativeElement.querySelector(".bg-graph-container");
    let rect = container.getBoundingClientRect();
    container.style.height = (rect.width * this.ratio) + "px";
    this.onScroll();
  }

  dismissTip() {
    this.tipDismissed = true;
    this.tipVisible = false;
  }

  onScroll() {
    if (!this.pdpMode) return;
    let container = this.el.nativeElement;
    if (!this.pdpOpened) {
      let rect = container.getBoundingClientRect();
      if (rect.top + (rect.height * 4) < window.innerHeight && !this.tipDismissed) {
        this.tipVisible = true;
      } else {
        this.tipVisible = false;
      }

    }
  }

  trackNewConnection(e) {
    e.preventDefault();

    this.analyticsService.trackCategoryEvent({
      eventInfo: {
        eventName: 'Book Graph Start New Connection',
        eventAction: 'onBookGraphStartNewConnection',
        timeStamp: new Date(),
      },
      category: {
        primaryCategory: 'Book Graph',
      },
      attributes: {
        errorCode: '',
        errorMessage: ''
      }
    }, 'onBookGraphStartNewConnection');

    window.location = e.target.href;
  }
}
