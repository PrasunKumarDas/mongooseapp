import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bg-root',
  templateUrl: './bootstrap.component.html',
  styleUrls: ['./bootstrap.component.scss']
})
export class BootstrapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
