import { Component, Input, OnInit, ChangeDetectorRef } from '@angular/core';
import { getAllBooks } from '../../reducers/books';
import { GraphService } from '../../services/graph.service';
import { IAppState } from '../../store';
import { NgRedux } from '@angular-redux/store';
import {
  updateBookState,
  updateHistory,
  recallHistory,
  popGraph,
  setLock,
  clearGraphErrors
} from '../../actions';
import { TweenMax } from 'gsap';

@Component({
  selector: 'bg-graph',
  templateUrl: './graph.component.html',
  styleUrls: ['./graph.component.scss']
})
export class GraphComponent implements OnInit {
  @Input() readonly graph;
  @Input() readonly isCurrent:boolean;
  private siblingGraphs;
  private books = [];
  private locked = false;

  constructor(private graphService: GraphService, private ngRedux: NgRedux<IAppState>, private cdr: ChangeDetectorRef) { }

  ngAfterViewInit() {
    this.cdr.detach();
  }

  ngOnInit() {
    this.books = getAllBooks(this.graph.books);
    this.ngRedux
      .select(state => state)
      .subscribe(state => {
        const graphState = state.graphs;
        if ( state.app.locked !== this.locked ) {
          this.locked = state.app.locked;
        }
        this.siblingGraphs = graphState.allIds.slice(-5).filter(id => id !== this.graph.id);
        this.books = getAllBooks(this.graph.books);
      })
  }

  onBookClick(selectedBook, event) {
    event.preventDefault();

    let bookState = this.graph.books.byId[selectedBook.id].state;
    if ( bookState === "selected" || this.locked ) {
      return;
    }
    this.ngRedux.dispatch(setLock(true));

    switch ( bookState ) {
      case "selected":
        break;
      case "history1":
      case "history2":

        this.ngRedux.dispatch(recallHistory());
        this.ngRedux.dispatch(clearGraphErrors());
        TweenMax.delayedCall(0.8, () => {
          this.ngRedux.dispatch(setLock(false));
          this.ngRedux.dispatch(popGraph());
        });
        break;
      case "loading":
      case "loaded": {
        this.ngRedux.dispatch(updateBookState(this.graph.id, selectedBook.id, 'selected'));

        if ( this.books.length > 1 ) {
          this.graphService.getGraph(selectedBook.ean, selectedBook);
          for ( let graphId of this.siblingGraphs ) {
            this.ngRedux.dispatch(updateHistory(graphId));
          }
          for ( let book of this.books ) {
            if ( selectedBook.id !== book.id ) {
              this.ngRedux.dispatch(updateBookState(this.graph.id, book.id, 'hidden'));
            }
          }
        }
      }
    }
  }

  // track by callback
  trackBook(index, book) {
    return book.id;
  }
}
