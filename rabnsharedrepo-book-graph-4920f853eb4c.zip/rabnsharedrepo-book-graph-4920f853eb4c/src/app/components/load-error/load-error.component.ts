import { Component, OnInit, Input } from '@angular/core';

declare const window;

@Component({
  selector: 'bg-load-error',
  templateUrl: './load-error.component.html',
  styleUrls: ['./load-error.component.scss']
})
export class LoadErrorComponent implements OnInit {

  @Input() error:any = false;
  @Input() pdpMode:boolean = false;

  constructor() { }

  ngOnInit() {
  }

  retry() {
    console.log('reload', window.location.reload);
    window.location.reload();
  }

}
