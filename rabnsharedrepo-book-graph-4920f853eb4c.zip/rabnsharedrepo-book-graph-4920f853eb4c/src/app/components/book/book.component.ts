import { Component, Input, ElementRef, ChangeDetectorRef } from '@angular/core';
import { TimelineMax, TweenMax, Power2, Power3 } from 'gsap';
import { IAppState } from '../../store';
import { NgRedux } from '@angular-redux/store';
import { GraphService } from '../../services/graph.service';
import { getAllBooks} from '../../reducers/books';
import { updateBookState, setDetailsOpened } from '../../actions';

const COLUMNS = [-30.96551724137931, -4.8965517241379315, 21.17241379310345, 40.206896551724135, 54, 64.96551724137932, 74.6896551724138, 84.34482758620689];
const ROWS = [14.307692307692307, 25.692307692307693, 37.07692307692308, 50, 62.92307692307693, 74.3076923076923, 85.6923076923077];
const SCALES = [1, 1, 1, 116/238, 86/238, 74/238, 74/238, 74/238];

declare let document;

@Component({
  selector: 'bg-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.scss']
})
export class BookComponent {
  @Input() readonly book;
  @Input() readonly parent;
  @Input() readonly currentGraph:boolean;

  private previousState;
  private bookState;
  private imageError=false;
  private selectedBook;

  constructor(
    private el: ElementRef,
    private ngRedux: NgRedux<IAppState>,
    private graphService: GraphService,
    private cdr: ChangeDetectorRef
  ) {}

  ngAfterViewInit() {
    this.cdr.detach();
  }

  isSelected() {
    return this.bookState === 'selected';
  }

  isLoaded() {
    return this.bookState === 'loaded';
  }

  isInert() {
    switch (this.bookState) {
      case 'loading':
      case 'loaded':
      case 'selected':
      case 'history1': {
        return false;
      }
      default: {
        return true;
      }
    }
  }

  handleChange() {
    switch ( this.bookState ) {
      case 'loading':
        TweenMax.set(this.el.nativeElement, {
          left: COLUMNS[this.book.column] + "%",
          top: ROWS[this.book.row] + "%",
          transformOrigin: "top left",
          scale: 0,
          autoAlpha: 0
        });
        break;
      case 'loaded':
        TweenMax.to(this.el.nativeElement, 0.3, {
          left: COLUMNS[this.book.column] + "%",
          top: ROWS[this.book.row] + "%",
          delay: (this.book.column / COLUMNS.length) * .3,
          autoAlpha: 1,
          display:"inherit",
          scale: SCALES[this.book.column],
          ease: Power2.easeInOut,
          onStart: () => {
            if ( this.previousState === 'selected' ) {
              this.cdr.detectChanges();
            }
          },
        });
        break;
      case 'selected':
        TweenMax.to(this.el.nativeElement, 0.7, {
          left: COLUMNS[2] + "%",
          top: ROWS[3] + "%",
          transformOrigin: "top left",
          scale: SCALES[2],
          autoAlpha:1,
          ease: Power3.easeInOut,
          onStart: () => {
            this.cdr.detectChanges();
          }
        });
        break;
      case 'hidden':
        let inverseScale = 1 / SCALES[this.selectedBook.column];

        let selectedX = COLUMNS[this.selectedBook.column];
        let selectedY = ROWS[this.selectedBook.row];

        let targetX = COLUMNS[2];
        let targetY = ROWS[3];


        let x = COLUMNS[this.book.column];
        let y = ROWS[this.book.row];

        let offsetX = (x - selectedX) * inverseScale;
        let offsetY = (y - selectedY) * inverseScale;

        TweenMax.to(this.el.nativeElement, 0.7, {
          left: (targetX + offsetX) + "%",
          top: (targetY + offsetY) + "%",
          transformOrigin: "top left",
          scale: SCALES[this.book.column] * inverseScale,
          ease: Power3.easeInOut,
          autoAlpha: 0,
          onComplete: () => {
            this.el.nativeElement.style.display = "none"
          },
        });
        break;

      case 'history1':
        TweenMax.to(this.el.nativeElement, 0.7, {
          left: COLUMNS[1] + "%",
          transformOrigin: "top left",
          ease: Power3.easeInOut,
          onStart: () => {
            this.cdr.detectChanges();
          },
        });
        break;

      case 'history2':
        TweenMax.to(this.el.nativeElement, 0.7, {
          left: COLUMNS[0] + "%",
          transformOrigin: "top left",
          ease: Power3.easeInOut
        });
        break;

      case 'exit':
        TweenMax.to(this.el.nativeElement, 0.3, {
          left: (COLUMNS[this.book.column] + 5) + "%",
          scale: SCALES[this.book.column] * 0.5,
          autoAlpha: 0,
          transformOrigin: "top left",
          ease: Power3.easeInOut
        });
        break;
    }
  }

  ngOnInit() {
    this.bookState = this.book.state;
    this.handleChange();

    this.ngRedux
      .select(state => state.graphs)
      .subscribe(graphs => {

        let graph = graphs.byId[this.parent.graph.id];
        if ( graph ) {
          let book = graph.byId[this.book.id];
          let allBooks = getAllBooks(graph);

          let bookList = allBooks.length > 1 ? allBooks.filter(book => book.state === 'selected') : allBooks;
          if ( bookList.length === 1 ) {
            this.selectedBook = bookList[0];
          }

          if (this.bookState !== book.state) {
            this.previousState = this.bookState;
            this.bookState = book.state;
            this.handleChange();
          }
        }
      });

  }

  bookCta() {
    return `Click to show books related to this book, ${this.book.title}.`;
  }

  onBookActivated($event, book) {
    if ( this.parent.locked ) return;

    if ( this.bookState === 'selected') {
      this.openDetails($event, $event.type === 'keyup');
    } else {
      this.parent.onBookClick(book, $event);
    }
  }

  onImageLoad() {
    if ( this.selectedBook && this.book.id === this.selectedBook.id ) {
      this.ngRedux.dispatch(updateBookState(this.parent.graph.id, this.book.id, 'selected'));
    } else {
      this.ngRedux.dispatch(updateBookState(this.parent.graph.id, this.book.id, 'loaded'));
    }
  }

  onImageError() {
    this.imageError=true;
    this.onImageLoad();
  }

  openDetails(event, focus = true){
    event.preventDefault();
    this.ngRedux.dispatch(setDetailsOpened(true));

    if ( focus ) {
      document.getElementById('details-panel').focus();
    }
  }
}
