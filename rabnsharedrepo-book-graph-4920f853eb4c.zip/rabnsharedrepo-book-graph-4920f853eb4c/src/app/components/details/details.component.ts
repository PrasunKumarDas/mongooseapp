import { Component, OnInit, Input, ElementRef } from '@angular/core';
import { TweenMax, Power2 } from 'gsap';
import 'gsap/ScrollToPlugin';

import { IAppState } from '../../store';
import { NgRedux } from '@angular-redux/store';

import { setDetailsOpened } from '../../actions';
import { getSelectedBook } from '../../reducers/graphs';
import { AnalyticsService } from '../../services/analytics.service';

declare let window, document;

@Component({
  selector: 'bg-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {
  private isOpen;
  private selectedBook;
  private details;

  constructor(private ngRedux: NgRedux<IAppState>, private el:ElementRef, private analyticsService:AnalyticsService) { }

  ngOnInit() {
    this.el.nativeElement.tabIndex = -1;
    this.ngRedux.select('app').subscribe(appState => {
      let isOpen = appState['detailsOpened'] || false;
      if ( this.isOpen !== isOpen ) {
        this.isOpen = isOpen;
        var details = this.el.nativeElement.querySelector(".bg-details-panel");
        if(details){
          if ( this.isOpen ) {
            TweenMax.set(details,{display:"inline"});
            TweenMax.to(details,0.3,{x:0,ease:Power2.easeOut});
            this.el.nativeElement.focus();
          }else{
            TweenMax.set(details,{delay:0.4, display:"none"});
            TweenMax.to(details,0.3,{x:details.getBoundingClientRect().width+30,ease:Power2.easeIn});
          }
        }
      }
    });

    this.ngRedux.select(state => state).subscribe(state => {
      const graphsState = state.graphs;
      const detailsState = state.details;

      if ( graphsState['allIds'] && graphsState['allIds'].length > 1 ) {
        let selectedBook = getSelectedBook(graphsState);
        if ( selectedBook ) {
          this.selectedBook = selectedBook;
        }
      }

      if ( this.selectedBook && detailsState['byId'][this.selectedBook.ean] ) {
        this.details = detailsState['byId'][this.selectedBook.ean];
      }
    });
  }

  contributors() {
    if ( this.details ) {
      return this.details.contributors || [];
    }

    return [];
  }

  reviews() {
    if ( this.details ) {
      return this.details.starreview.reviews || 0;
    }

    return 0;
  }

  rating() {
    if ( this.details ) {
      return Math.round(this.details.starreview.stars * 2) / 2 || 0;
    }

    return 0;
  }

  closeDetails(event, focus = false){
    event.preventDefault();
    this.ngRedux.dispatch(setDetailsOpened(false));
    if ( focus ) {
      document.querySelector('.book-component__content.selected .book-component__link').focus();
    }
  }

  trackPdp(e) {
    e.preventDefault();
    // this.analyticsService.trackCategoryEvent('details', 'product-select', `${this.selectedBook.ean}: ${this.selectedBook.title}`);
    window.location = e.target.href;
  }
}
