import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'truncateAt'
})
export class TruncateAtPipe implements PipeTransform {

  transform(value: any, character?: String): any {
    let index = value.indexOf(character);
    index = index==-1?value.length:index;
    value = value.substring(0,index);
    return value;
  }

}
