import { TruncateAtPipe } from './truncate-at.pipe';

describe('TruncateAtPipe', () => {
  it('create an instance', () => {
    const pipe = new TruncateAtPipe();
    expect(pipe).toBeTruthy();
  });
});
