import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'reverseOrder'
})
export class ReverseOrderPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    return value.slice().reverse();
  }

}
