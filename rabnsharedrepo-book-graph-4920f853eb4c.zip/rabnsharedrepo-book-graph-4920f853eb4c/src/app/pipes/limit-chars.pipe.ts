import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'limitChars'
})
export class LimitCharsPipe implements PipeTransform {

  transform(value: any, args?: Number): any {
    let limit = args || -1;
    if ( limit > 0 && value.length > limit ) {
      value = value.trim().replace(/^<[pP][^>]*>|<\/[pP]>$/g, '');

      return value.slice(0, limit) + '…';
    }

    return value;
  }

}
