# BookGraph

### Node Version Requirements

Node version `7.8.0` or later to build or run the development server.

* [Instructions for integration](docs/integration.md)
* [Instructions for maintenance and local development](docs/maintenance.md)
