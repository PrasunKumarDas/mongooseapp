import { BookGraphPage } from './app.po';

describe('book-graph App', () => {
  let page: BookGraphPage;

  beforeEach(() => {
    page = new BookGraphPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('bg works!');
  });
});
