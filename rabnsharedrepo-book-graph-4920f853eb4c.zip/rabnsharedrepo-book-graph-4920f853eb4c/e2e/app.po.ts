import { browser, element, by } from 'protractor';

export class BookGraphPage {
  navigateTo() {
    return browser.get('/');
  }

  getParagraphText() {
    return element(by.css('bg-root h1')).getText();
  }
}
