# Integration

## Install Dependencies

Run `npm install` to install dependencies.

## Build the app for Hosted Deployment

To build the app for hosted deployment, connecting to api service at `http://awerenis01.hq.bn-corp.com/ucdata/`, run the following command:

`NODE_ENV=production API_URL='http://awerenis01.hq.bn-corp.com/ucdata/' npm run build`

This with build artifacts into the `dist/` directory. The `book-graph.bundle.js` file will need to be deployed to your web server. Ideally, this file should be gzipped and served from a CDN along with the rest of the site's static assets.

The Book Graph application also has dependencies (CSS styles and some Javascript behaviors) from the R/A toolkit assets - `toolkit.css`, `toolkit.js` and `vendor.js`. The R/A toolkit Javascript assets should load before the `book-graph.bundle.js`.

### Set the API URL via environment variables

To provide the production configuration, provide the `NODE_ENV`, `API_URL`, and `API_SUFFIX` variables. The `NODE_ENV` property tells the application to run in production mode if set to that value and removes/silences some of the debugging features in Angular so the application runs faster. The `API_SUFFIX` is only required if query parameters are needed for the API calls.

Example Build with an API_URL corresponding to the current BN Book Graph API:

`NODE_ENV=production API_URL='http://awerenis01.hq.bn-corp.com/ucdata/' NEW_CONNECTION_URL='/recommendations.html' npm run build`

### API Service Calls

This web application will make requests against the API via a GET method using the API_URL + the book EAN. For example, if the application is built with the above API_URL environment variable set, as above:

`http://awerenis01.hq.bn-corp.com/ucdata/9780316407090`

The application would call the above URL in this example to query the book graph for book with EAN 9780316407090.

Any `API_SUFFIX` provided during build will be the suffix of the above call (default: ''), for example:

`NODE_ENV=production API_URL='http://awerenis01.hq.bn-corp.com/ucdata/' API_SUFFIX='?myParam=value' npm run build`

The above build would result in a compiled application that will make API requests like:

`http://awerenis01.hq.bn-corp.com/ucdata/9780316407090?myParam=value`

### Recommendations

Provide the `NEW_CONNECTION_URL` as above to the path to the grid of recommended books that will take you to the stand alone book graph. For example, if the book grid of recommendations were to be hosted at `/b/discover/_/books/pets/_/N-29Z8q8Z1fjz`, you will need to provide that during the build in place of `/recommendations.html` in the build command above:

`NODE_ENV=production API_URL='http://awerenis01.hq.bn-corp.com/ucdata/' NEW_CONNECTION_URL='/b/discover/_/books/pets/_/N-29Z8q8Z1fjz' npm run build`

### Build Assets

In addition to the BN toolkit codebase (latest `toolkit.js`, `vendor/vendor.js` and `toolkit.css` are required), which for this demo site of the application has included as a submodule, the following asset will need to able to load on the page from the same path:

- dist/book-graph.bundle.js

See above (Build the app for Hosted Deployment) for build instructions.

### HTML Integration

Once the toolkit and above assets are loaded, include the following element on the page to bootstrap the component:

`<bg-root></bg-root>`

### Loading a book graph

The book graph application will get the loaded book from one of **two** methods:

#### Method 1 - by digitalData SKU value

On the current B&N product detail page, there is a javascript data structure describing the product information on that page. If the digitalData SKU value is found on the page, it will be used to load the graph.

**The script below is from [Cross the Line (Alex Cross Series #24)](www.barnesandnoble.com/w/cross-the-line-jack-patterson/1113823936?ean=9780316407090) product detail page:**

```
<script type="text/javascript">
var digitalData = {
    "product": [{
        "category": {
            "primaryCategory": "Books",
            "subCategory": ["Crime Thrillers", "Thrillers - Serial Killers"],
            "productType": "book"
        },
        "price": {
            "basePrice": 17.46
        },
        "productInfo": {
            "sku": "9780316407090",
            "productName": "Cross the Line (Alex Cross Series #24)",
            "productID": "prd9780316407090",
            "productURL": "/w/cross-the-line-jack-patterson/1113823936?ean=9780316407090"
        },
        "attributes": {
            "outOfStock": false,
            ...
</script>
```



#### Method 2 - By URL fragment

If you call the URL that is hosting the book graph, and pass a link to it with a fragment in the following form:

`http://barnesandnoble.com/path/to/bookgraph#/book/{:ean}` where {:ean} is replaced with the EAN of the loaded book.

Example: Say the path to the bookgraph application page is `http://www.barnesandnoble.com/book-graph` and the book you wish to load the graph for has an EAN of 9780316407090, the full url to the book graph with this book loaded would be:

`http://www.barnesandnoble.com/book-graph#/book/9780316407090`

## Application Maintenance

### Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive/pipe/service/class/module`.

### Further help with Angular 4

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
