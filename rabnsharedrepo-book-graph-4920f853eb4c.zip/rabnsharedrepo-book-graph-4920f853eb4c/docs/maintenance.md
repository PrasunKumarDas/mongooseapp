# Local Development and Maintenance

## Install Dependencies

Run `npm install` to install dependencies.

## Run the app for a Local Development

By default, running the `npm start` command with no environment variables set will try to connect the app to a locally running mock service. If you don't have that service running, choose one of the other options below.

To run the app against the R/A mock service API:

`API_URL='http://barnesandnoble-bookgraph.r-a.io/services/books2/' npm start`

To run the app against the BN API (VPN needed from the R/A office):

`API_URL='http://awerenis01.hq.bn-corp.com/ucdata/' npm start`

The app will be available by default at port 4200 and will automatically reload if you change any of the source files.

Local application URLs:

- *Sample standalone page:* `http://localhost:4200/#/book/9780316407090`
- *Sample Recommendation Landing page:* `http://localhost:4200/recommendations.html`
- *Sample PDP:* `http://localhost:4200/pdp-books.html#/`
- *App-only page for accessibility testing:* `http://localhost:4200/a11y.html#/`

### Running aXe Accessibility test

After starting the application locally, run `npm run axe` to test the standalone application for accessibility issues.

## Application Maintenance

### Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive/pipe/service/class/module`.

### Further help with Angular 4

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
